# iron_worker_ng-0.1.6

root = nil

($*.length - 2).downto(0) do |i|
  root = $*[i + 1] if $*[i] == '-d'
end

Dir.chdir(root)



puts `java -cp vente_enchere_auto_worker.jar JavaHelloWorker #{$*.join(' ')}`
